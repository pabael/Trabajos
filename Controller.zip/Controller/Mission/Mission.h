#ifndef MISSION_H
#define MISSION_H

#include <iostream>
#include <string>
#include <fstream>
#include <jsoncpp/json/json.h> 
#include "../../ClasesNecesarias/Point2D.h"

class mission{

    private:
    int num; //num de misiones
    vector<Point2D> destinos; 

    public: 
    mission();
    ~mission();
    mission(string nombre);
    vector<Point2D> GetMisiones();
    int GetNum();

};

#endif