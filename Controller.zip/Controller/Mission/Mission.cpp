#include "Mission.h"

mission::mission(){
}

mission::~mission(){
}

mission::mission(string nombre){

    ifstream datos(nombre);
    Json::Reader reader;
    Json::Value j;

    reader.parse(datos, j);

    const Json::Value& misionesX = j["Mission"][0]["CoordenadasX"];
    const Json::Value& misionesY = j["Mission"][0]["CoordenadasY"];
    vector<double> destinosX;
    vector<double> destinosY;
    for(Json::ValueConstIterator it = misionesX.begin(); it != misionesX.end(); it++){
        const Json::Value& misionX = *it;
        destinosX.push_back(misionX.asDouble());
    }

    for(Json::ValueConstIterator it = misionesY.begin(); it != misionesY.end(); it++){
        const Json::Value& misionY = *it;
        destinosY.push_back(misionY.asDouble());
    }

    if (destinosX.size()==destinosY.size()){
        this->num = destinosX.size();
        for(int i=0; i<destinosX.size();i++){

            Point2D p (destinosX[i], destinosY[i]);
            destinos.push_back(p);
        }

    }else {
        cout << "Destinos introducidos incorrectos \n";
    }

}

vector<Point2D> mission::GetMisiones(){
    return destinos;
}

int mission::GetNum(){
    return num;
}
