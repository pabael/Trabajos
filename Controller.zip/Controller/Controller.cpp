#include "Controller.h"


Controller::Controller(){
}

Controller::~Controller(){
}

Controller::Controller(Planificador plan, Mat im, scene escenario){
    
    CellDecomp m = plan.GetCellDecomp();
    PlanningPath planning = plan.GetPlanningPath(); 

    
    Mat im2;
    bool sePuede;
    int celdaInic;
    vector<int> celdasInics;
    vector<int> robots;
    bool final =false;
    Point2d  p2;
    int lineType = LINE_4;
    int thickness = 2;
    int robot;
    clock_t start, end;
    float media =0;

    if(plan.GetPaths().size()!=0){
    for(int i=0; i<planning.GetCaminos().size(); i++){
            robots.push_back(planning.GetRobotQueCelda()[i]); 
            for(int k=0; k<planning.GetCaminos()[i].size(); k++){
                if(planning.GetCaminos()[i][k]==planning.GetRobotQueCelda()[i]){
                        celdasInics.push_back(k);
                        k=planning.GetCaminos()[i].size();  
                }
            }
        }

    sePuede = Banker(m, planning, celdasInics, 0, robots);
    
    if(sePuede){

        cout << "Estado inical seguro \n"; 
        sePuede=false;

        do{
        im2=im.clone();
        robots.clear();
        celdasInics.clear();
        start = clock();
        for(int i=0; i<planning.GetCaminos().size(); i++){
            robots.push_back(planning.GetRobotQueCelda()[i]); 
            
            for(int k=0; k<planning.GetCaminos()[i].size(); k++){
                if(planning.GetCaminos()[i][k]==planning.GetRobotQueCelda()[i]){
                        celdasInics.push_back(k);
                        k=planning.GetCaminos()[i].size();  
                }
            }
        }
        

        robot = rand() % robots.size();
            if(planning.GetRobotQueCelda()[robot]!=planning.GetCaminos()[robot][planning.GetCaminos()[robot].size()-1]){
                
                celdasInics[robot]=celdasInics[robot]+1;
                robots[robot]=planning.GetCaminos()[robot][celdasInics[robot]];
                sePuede = Banker(m, planning,celdasInics, robot, robots);
            
                if(sePuede){
                    
                    planning.RobotQueCeldaSimulador(robot, m.GetCelda(planning.GetCaminos()[robot][celdasInics[robot]]).GetNum());
                    Dibujar(planning, m, escenario, celdasInics, plan, im2);
                }
            }
        end = clock();
        if(media==0){
            media=float(end - start)/CLOCKS_PER_SEC;
        }else{
            media = (media + float(end - start)/CLOCKS_PER_SEC)/2;
        }
        
        for(int j=0; j<planning.GetCaminos().size(); j++){
            if(planning.GetRobotQueCelda()[j]==planning.GetCaminos()[j][planning.GetCaminos()[j].size()-1]){
                final=true;
            } else{
                final=false;
                j=planning.GetCaminos().size();
            }
        }

    }while(!final);

    cout << "Han llegado a su destino \n";

    this ->mediaC = media;

    }else{cout << "Estado inical no seguro \n";}

    
    //cout << media << " media \n";
    }
}

float Controller::GetMedia(){
    return mediaC;
}


bool Controller::Banker(CellDecomp m,PlanningPath planning,  vector<int> celdasInics, int robot, vector<int> robots){
    bool seguro = true;
    bool pueden = true;
    vector<int> Nopueden;
    int no=0;

    for(int i=0; i<robots.size();i++){
        if(i!=robot && robots[robot] ==robots[i]){
            seguro=false;
            i=robots.size();        
        }else{
            seguro=true;
        }
    }
    if(seguro){
        while(pueden){    
            for(int i=0; i<robots.size(); i++){
                seguro=true;
                for(int j=celdasInics[i]; j<planning.GetCaminos()[i].size();j++){ 
                    for(int k =0; k<robots.size();k++){                        
                        if(i!=k && m.GetCelda(planning.GetCaminos()[i][j]).GetNum()==robots[k]){
                            seguro =false;
                            k=robots.size();
                            j=planning.GetCaminos()[i].size(); 
                            Nopueden.push_back(i);
                        }
                    }
                }
                if(seguro){
                    robots[i]=planning.GetCaminos()[i][planning.GetCaminos()[i].size()-1];
                    
                }
            }
            
            if(Nopueden.size()==0 || no==Nopueden.size()){
                pueden=false;

            }
            no=Nopueden.size();
            Nopueden.clear();

        }

        if(no==0){
            seguro=true;
        }else {
            seguro=false;
        }
        
    }

    return seguro;
}  

void Controller::Dibujar(PlanningPath planning2, CellDecomp m, scene escenario, vector<int> celdasInics, Planificador plan, Mat im ){
    
    Mat im2;
    vector<int> robots;
    Point2d  p0, p1, p2;
    int lineType = LINE_4;
    int thickness = 2;

    for(int i=0; i<planning2.GetCaminos().size(); i++){
    
        robots.push_back(planning2.GetRobotQueCelda()[i]); 
        p0=escenario.ConversionPlatformToCV(m.GetCelda(robots[i]).GetCentro());
        circle(im, p0, 5, Scalar (0, 0, 0), thickness); 
        for(int j=0; j<celdasInics[i] ;j++){
            p1=escenario.ConversionPlatformToCV(plan.GetPaths()[i][j]);
            p2=escenario.ConversionPlatformToCV(plan.GetPaths()[i][j+1]);
            line (im,p1, p2, Scalar (0, 0, 0) , thickness, lineType ); 
        }   
    }
    imshow("Banquero", im);
    waitKey(10);
    std::this_thread::sleep_for(chrono::milliseconds(200));


}
