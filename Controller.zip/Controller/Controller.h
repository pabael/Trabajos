
#ifndef CONTROLLER_H
#define CONTROLLER_H

#include "PlanningPath/Planificador/Planificador.h"
#include <thread>
#include <chrono>


class Controller{

private:
 
float mediaC;

public:
    
    Controller();
    ~Controller();
    Controller(Planificador plan, Mat im, scene escenario);
    float GetMedia();
    bool Banker(CellDecomp m,PlanningPath planning,  vector<int> celdasInics, int robot, vector<int> robots);
    void Dibujar(PlanningPath planning2, CellDecomp m, scene escenario, vector<int> celdasInics, Planificador plan, Mat im );
};

#endif