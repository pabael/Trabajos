    #include "PlanningPath.h"
    
    PlanningPath::PlanningPath(){     
    }
    PlanningPath::~PlanningPath(){
    }
    PlanningPath::PlanningPath(mission mision, Graph graph , CellDecomp m, scene escenario){
        
        
        //RobotQueCelda(m, escenario);
        RobotQueCeldaInicialSimulador();
        DestinoQueCelda(m, mision);

        clock_t start, end;
        float media =0;

            typedef adjacency_list <vecS,vecS,directedS,property<vertex_distance_t, int>,property<edge_weight_t, int>, no_property, listS> graph_t;
            typedef graph_traits < graph_t >::vertex_descriptor vertex_descriptor;
            graph_t g =graph.GetGraph() ;
            property_map<graph_t, vertex_distance_t>::type distance = get(vertex_distance_t(), g);
            property_map<graph_t, edge_weight_t>::type w = get(edge_weight_t(), g);
            
            vector<int> trajectory; //una trayectoria
            vector<vector<int>> trayectorias; //las trayectorias de todos los robots
            vector<Point2D> misiones = mision.GetMisiones();

          //cout << celdaInicialRobots.size() << " " << CeldasDestinos.size() << " " << misiones.size() << "\n";
        if(celdaInicialRobots.size()==CeldasDestinos.size() && CeldasDestinos.size()&& misiones.size() ){
            start = clock();
            for(int i=0; i< misiones.size(); i++){ //Para cada robot            
                std::vector< vertex_descriptor > p(num_vertices(g));
                std::vector< int > d(num_vertices(g));

                vertex_descriptor start = vertex(celdaInicialRobots[i], g);             
                vertex_descriptor target = vertex(CeldasDestinos[i], g);

                dijkstra_shortest_paths(g, start,
                predecessor_map(boost::make_iterator_property_map(
                    p.begin(), get(boost::vertex_index, g)))
                .distance_map(boost::make_iterator_property_map(
                    d.begin(), get(boost::vertex_index, g))));

                std::vector< vertex_descriptor > path;
                vertex_descriptor current = target;

                while (current != start) {
                    path.push_back(current);
                    current = p[current];
                }

                path.push_back(start);

                //This prints the path reversed use reverse_iterator and rbegin/rend
                std::vector<vertex_descriptor >::reverse_iterator rit;
                for (rit = path.rbegin(); rit != path.rend(); ++rit) {
                    trajectory.push_back(*rit);                          
                }
                    
                //cout << "robot: " << i << " -> " << trajectory.size() << "\n";
                trayectorias.push_back(trajectory);
                trajectory.clear();

                
            }
            end = clock();

            if(media==0){
                media=float(end - start)/CLOCKS_PER_SEC;
            }else{
                media = (media + float(end - start)/CLOCKS_PER_SEC)/2;
            }
            

        }else  cout <<"No se han detectado bien los robots \n";
        
        //cout << media << " -> Media calculo trayectoria: \n";
       
        
        this -> caminos = trayectorias;

    }



    void PlanningPath::RobotQueCelda(CellDecomp m, scene escenario){

        vector<int> celdas;
        vector<robot> robots = escenario.getListRobot();
        vector<Point2d> posiciones;
        for(int i=0; i<robots.size(); i++){
            posiciones.push_back(robots[i].getPosition());
        }
        
        bool dentro;
        for(int i=0; i< posiciones.size();i++){
            for(int j =0; j<m.GetSize();j++){
                dentro = m.GetCelda(j).PuntoDentro((posiciones[i]));
                if(dentro){
                    celdas.push_back(m.GetCelda(j).GetNum());                    
                }                
            }
            //cout << "robot coordenadas: " << posiciones[i].x << " " << posiciones[i].y <<"\n";                      
        }

        
        
        if(celdas.size()==robots.size()){ //robots dentro de la plataform
        this ->  celdaInicialRobots = celdas;
        }
    }

    void PlanningPath::RobotQueCeldaSimulador(int num, int celda){
        vector<int> celdas;
        celdas=celdaInicialRobots;
        celdas[num]=celda;
        this ->  celdaInicialRobots = celdas;
    }

    void PlanningPath::RobotQueCeldaInicialSimulador(){
        vector<int> celdas(12);
        this -> celdaInicialRobots = celdas;
        RobotQueCeldaSimulador(0, 35);
        RobotQueCeldaSimulador(1, 20);
        RobotQueCeldaSimulador(2, 69);
        RobotQueCeldaSimulador(3, 120);
        RobotQueCeldaSimulador(4, 137);
        RobotQueCeldaSimulador(5, 185);
        RobotQueCeldaSimulador(6, 183);
        RobotQueCeldaSimulador(7, 181);
        RobotQueCeldaSimulador(8, 31);
        RobotQueCeldaSimulador(9, 29);
        RobotQueCeldaSimulador(10, 27);
        RobotQueCeldaSimulador(11, 22);
        
        
    }

    void PlanningPath::CeldaInicialRealSim(CellDecomp m){
        vector<int> camino;
        vector<vector<int>> trayectorias;
        vector <int> puntosIguales;
        Point2D p, p1, p2;
        for(int k=0; k<caminos.size();k++){   
            for(int j=0; j<m.GetAreaDescanso().size();j++){
                    for(int c=0; c<m.GetCelda(caminos[k][0]).GetEsquinas().size();c++){
                        p1 = m.GetCelda(caminos[k][0]).GetEsquina(c);
                        for(int b=0; b<m.GetCelda(caminos[k][0]).GetEsquinas().size();b++){
                            p2 = m.GetCelda(m.GetAreaDescanso()[j]).GetEsquina(b);
                            if(int (p1.GetX()) == int(p2.GetX()) && int (p1.GetY()) == int(p2.GetY())){
                                puntosIguales.push_back(1);
                                b=m.GetCelda(caminos[k][0]).GetEsquinas().size();                                
                            }
                        }

                    }
                    if(puntosIguales.size()==2){
                        camino.push_back(m.GetAreaDescanso()[j]);
                        RobotQueCeldaSimulador(k,m.GetAreaDescanso()[j]);
                        j=m.GetAreaDescanso().size();
                    }
                    puntosIguales.clear();
                    
                }

                for(int h=0; h<caminos[k].size(); h++){
                    
                    camino.push_back(m.GetCelda(caminos[k][h]).GetNum());
                    
                } 

                for(int j=0; j<m.GetAreaDescanso().size();j++){
                    for(int c=0; c<m.GetCelda(caminos[k][caminos[k].size()-1]).GetEsquinas().size();c++){
                       
                            p1 = m.GetCelda(caminos[k][caminos[k].size()-1]).GetEsquina(c);
                            for(int b=0; b<m.GetCelda(caminos[k][caminos[k].size()-1]).GetEsquinas().size();b++){
                                p2 = m.GetCelda(m.GetAreaDescanso()[j]).GetEsquina(b);
                                                                
                                if(int (p1.GetX()) == int(p2.GetX()) && int (p1.GetY()) == int(p2.GetY())){
                                    puntosIguales.push_back(1);
                                    b=m.GetCelda(caminos[k][caminos[k].size()-1]).GetEsquinas().size();
                                }
                            }

                        }
                    if(puntosIguales.size()==2){
                        camino.push_back(m.GetAreaDescanso()[j]);
                        j=m.GetAreaDescanso().size();
                    }
                    puntosIguales.clear();   
            } 
            
            trayectorias.push_back(camino);
            
            camino.clear();   
        }
        
        
        this->caminos = trayectorias;
        
    }

    

    void PlanningPath::DestinoQueCelda(CellDecomp m, mission mision){

        vector<int> celdas;
        
        bool dentro;
        for(int i=0; i< mision.GetMisiones().size();i++){
            Point2d p (mision.GetMisiones()[i].GetX(), mision.GetMisiones()[i].GetY());
            
            for(int j =0; j<m.GetSize();j++){                
                dentro = m.GetCelda(j).PuntoDentro(p);

                if(dentro && m.GetCelda(j).GetState()==0){
                    celdas.push_back(m.GetCelda(j).GetNum());  
                    //cout << m.GetCelda(j).GetNum() << " robot: "  << i << "\n";
                    //m.GetCelda(j).print() ;
                }
                else if (dentro && m.GetCelda(j).GetState()==1){
                    celdas.clear();
                    cout << "El destino " << i << " se encuentra en un obstaculo \n ";
                    j=m.GetSize();
                }
                
            }   
         
        }
        this ->  CeldasDestinos = celdas;

    }

    vector<vector<int>> PlanningPath::GetCaminos(){
        return caminos;
    }

    vector<int> PlanningPath::GetRobotQueCelda(){
        return celdaInicialRobots;
    }

    vector<int> PlanningPath::GetDestinoQueCelda(){
        return CeldasDestinos;
    }

    void PlanningPath::print(){
        for(int k=0; k<caminos.size();k++){
            cout << "trayectoria: " << k << " " << caminos[k].size();
            
            for(int h=0; h<caminos[k].size(); h++){
                cout << " ; " << caminos[k][h] ;
            }
            cout << "\n";
        }
    }