#include "CellDecomp.h"

CellDecomp::CellDecomp(){
}
CellDecomp::~CellDecomp(){
}
int CellDecomp::GetSize(){
    return this->num;
}
vector<Celda> CellDecomp::GetCellDecomp(){
    return this->cellDecomp;
}
Celda CellDecomp::GetCelda(int n){
    return cellDecomp[n];
}

vector<int> CellDecomp::GetAreaDescanso(){
    return zonaDescanso;
}

void CellDecomp::print (){
    cout << "Número de celdas: " << num << "\n";
    Celda cel;
    for (int i=0; i!=num; i++ ){
        cel = cellDecomp[i];
        cel.print();

    }
}
void CellDecomp::Dibujo(Mat im, scene escenario){

    int lineType = LINE_4;
    int thickness = 2;
    Point2d P1_rot, P2_rot;
    for(int i=0; i<cellDecomp.size();i++){
        for(int j=0; j<4; j++){                 
            P1_rot = escenario.ConversionPlatformToCV(cellDecomp[i].GetEsquina(j));            
            if(j!=3){
                P2_rot = escenario.ConversionPlatformToCV(cellDecomp[i].GetEsquina(j+1));
              line ( im,P1_rot, P2_rot, Scalar (255,255,255), thickness, lineType );
            } else {
                P2_rot = escenario.ConversionPlatformToCV(cellDecomp[i].GetEsquina(0));
              line ( im,P1_rot, P2_rot, Scalar (255,255,255), thickness, lineType );               
            }      
        }
    }
    imshow("cellDecomp", im);
}