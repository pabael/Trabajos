#ifndef CELLDECOMP_H
#define CELLDECOMP_H

#include "Malla/Celda/CuatroLados/CuatroLados.h"
#include <vector>
#include <iostream>
#include <string.h>
#include <cmath>
#include "../../../../Scene/Scene.h"
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

class CellDecomp{

  protected:

    int num; //num de celdas
    vector<Celda> cellDecomp;
    vector<int> zonaDescanso;

  public:

    CellDecomp();
    ~CellDecomp();
    int GetSize();
    vector<Celda> GetCellDecomp();
    Celda GetCelda(int n);
    vector<int> GetAreaDescanso();
    void print ();
    void Dibujo(Mat im, scene escenario);

};

#endif