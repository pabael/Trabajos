#ifndef MALLA_H
#define MALLA_H


#include "../CellDecomp.h"
#include <vector>
#include <iostream>
#include <string.h>
#include <cmath>

class Malla : public CellDecomp {

    private :

    int columnas;
    int filas;
    double ladoCuadrados;

    public:
      
      Malla(scene escenario);
      void crear(scene escenario);     
      void Descanso();

};

#endif