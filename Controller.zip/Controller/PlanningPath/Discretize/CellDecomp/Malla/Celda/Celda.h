#ifndef CELDA_H
#define CELDA_H

//#include "../../../../ClasesNecesarias/Segment.h"
#include "../../../../../../ClasesNecesarias/Point2D.h"
#include <vector>
#include <iostream>
#include "../../../../../../Scene/Scene.h"
#include <boost/geometry.hpp>


using namespace std;
using namespace boost;
namespace bg = boost::geometry;
namespace bgm = boost::geometry::model;
using namespace boost::assign;


class Celda{

  protected:

    int num;
    int state; // 0 vacía, 1 obstaculo, 2 robot
    vector <Point2D> esquinas;
    Point2D centro;

  public:

    Celda();
    ~Celda();
    Celda(int n);
    void SetState(scene escenario);
    void SetStateRobot();
    int GetState();
    vector<Point2D> GetEsquinas();
    Point2D GetEsquina(int n);
    int GetNum();
    Point2D GetCentro();
    void print();    
    bool PuntoDentro(Point2d p);
   

};

#endif