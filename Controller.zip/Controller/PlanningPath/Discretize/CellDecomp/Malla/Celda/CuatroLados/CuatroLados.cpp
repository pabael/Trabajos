#include "CuatroLados.h"

CuatroLados::CuatroLados(int num, Point2D p0, double width, double length) : Celda(num){

    SetEsquinas(p0,width, length);
    SetCentro();
}

void CuatroLados::SetEsquinas(Point2D pa, double w, double l){

    Point2D pb (pa.GetX(),(pa.GetY()+l)); // esquina superior izq 
    Point2D pc ((pa.GetX()+w),(pa.GetY()+l)); // esquina superior dcha 
    Point2D pd ((pa.GetX()+w),(pa.GetY())); //esquina inferior dcha 
    vector<Point2D> esq = {pa,pb,pc,pd};
    this->esquinas = esq;

}


void CuatroLados::SetCentro(){
        
        Point2D esq0 = esquinas[0];
        Point2D esq1 = esquinas[1];
        Point2D esq2 = esquinas[2];
        double x;
        double y;

        if(esq0.GetX()!=esq1.GetX()){
            x = (esq0.GetX()+ esq1.GetX())/2;
        }
        else {
            x = (esq0.GetX()+ esq2.GetX())/2;
        }
        if(esq0.GetY()!=esq1.GetY()){
            y = (esq0.GetY() + esq1.GetY())/2;        
        }
        else {
            y = (esq0.GetY() + esq2.GetY())/2;
        }
        
        //Aunque se introduzcan las esquinas en otro orden, siempre dará bien el centro.

        Point2D c (x,y);      
        this->centro = c;
        
}
