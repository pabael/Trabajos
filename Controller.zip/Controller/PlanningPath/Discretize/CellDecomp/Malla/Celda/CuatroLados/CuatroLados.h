#ifndef CUATROLADOS_H
#define CUATROLADOS_H

#include "../Celda.h"
#include <vector>
#include <iostream>

using namespace std;

class CuatroLados : public Celda {


    public:

        CuatroLados(int num, Point2D p0, double width, double length);
        void SetEsquinas(Point2D pa, double w, double l);
        void SetCentro();

};

#endif