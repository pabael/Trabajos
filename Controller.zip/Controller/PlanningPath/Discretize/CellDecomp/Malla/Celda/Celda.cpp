#include "Celda.h"


    Celda::Celda(){
    }

    Celda::~Celda(){
    }

    Celda::Celda(int n){
        this->num = n;
    }

    void Celda::SetState(scene escenario){
        
        typedef boost::geometry::model::d2::point_xy<double> point_xy;
        typedef boost::geometry::model::polygon<point_xy> polygon; 

        polygon poly1;

        for(int j=0; j<esquinas.size(); j++){
            boost::geometry::append(poly1.outer(), point_xy(esquinas[j].GetX(),esquinas[j].GetY()));    
        }
        boost::geometry::append(poly1.outer(), point_xy(esquinas[0].GetX(),esquinas[0].GetY())); //volver a añadir la esquina 0 para cerrar el poligono
 
        bool contiene;
        int estado=0;

        vector<roi> obs = escenario.getListObstacles();

        for (int i=0; i<obs.size(); i++){ //compruebo todos los rois
            roi roi = obs[i];
            vector<vector<double>> contour = roi.getContour();
                        
            polygon poly2;           

            for(int j=0; j<contour.size(); j++){
                boost::geometry::append(poly2.outer(), point_xy(contour[j][0], contour[j][1]));    
            }

            boost::geometry::append(poly2.outer(), point_xy(contour[0][0], contour[0][1])); //volver a añadir la esquina 0 para cerrar el poligono
 
            contiene = boost::geometry::intersects(poly1,poly2);
            if(contiene){

                estado = 1;
                i=contour.size();
                
            }

        }



        this -> state = estado;  
        
    }

    int Celda::GetState(){
        return state;
    }

    vector<Point2D> Celda::GetEsquinas(){
        return esquinas;
    }

    Point2D Celda::GetEsquina(int n){

        if(n<esquinas.size()){
            return esquinas[n];
        }else{
            cout << "No existe esa esquina" << "\n";
        }
    }

    int Celda::GetNum(){
        return num;
    }


    Point2D Celda::GetCentro(){
        return centro;
    }

    bool Celda::PuntoDentro(Point2d p){

      typedef boost::geometry::model::d2::point_xy<double> point_xy;
      typedef boost::geometry::model::polygon<point_xy> polygon; 

        polygon poly1;
        bool dentro;

        for(int j=0; j<esquinas.size(); j++){
            boost::geometry::append(poly1.outer(), point_xy(esquinas[j].GetX(),esquinas[j].GetY()));    
        }
        boost::geometry::append(poly1.outer(), point_xy(esquinas[0].GetX(),esquinas[0].GetY())); //volver a añadir la esquina 0 para cerrar el poligono
        
        point_xy point (p.x,p.y);

        dentro=boost::geometry::within(point, poly1);
        
        return dentro;
    }
      
    void Celda::print(){

        int i;
        cout << "Celda " << num << ": [";
        for (i=0; i<esquinas.size(); i++){
            
            esquinas[i].print();
            
            if (i!=(esquinas.size()-1)){
                cout << " ; ";   
            }        
        }
        cout << "]" << "\n";
    }

