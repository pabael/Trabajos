#include "Malla.h"

Malla::Malla(scene escenario): CellDecomp(){

    crear(escenario);
    Descanso();
    
}

void Malla::crear(scene escenario){
    //double sizeL = 25; 
    double sizeL = escenario.getRobotRad()*2*100; 
    double areaCuadrados = sizeL*sizeL;
    vector<Celda> m;
    vector<int> descanso;
    vector<Point2f> lim = escenario.GetLimite();

    //Num de celdas en la horizontal
    double length = escenario.getLength()*100;
    int numH = (int)length/sizeL; //num de celdas en la horizontal

    //Num de celdas en la vertical
    double width = escenario.getWidth()*100;
    int numV = (int)width/sizeL;//num de celdas en la vertical 

    int n=0;

    Point2D p;
    for(int i=0;i<numV; i++){ 
        //cout << "\n"; 
        //cout << "nueva linea  \n";
        for (int j=0;j<numH;j++){ //creo celdas
             //punto izq abajo de las celdas
             p.SetX(j*sizeL);
             p.SetY(i*sizeL);
            Celda *nueva_celda = new CuatroLados(n, p, sizeL, sizeL);
            m.push_back(*nueva_celda);
            n++;                       
        }    
    } 

    double restoH = fmod(length,sizeL);
    double areaH = restoH*sizeL;//Area de los ultimos cuadrados en la horizontal
    bool h = false;

    if(areaH/areaCuadrados > 0.8){
        numH++;
        h=true;
    }
    
    if(h){  
        for (int j=0;j<numV;j++){ //creo celda
             //punto izq abajo de las celdas
            p.SetX((numH-1)*sizeL);
            p.SetY(j*sizeL);
            Celda *nueva_celda = new CuatroLados(n, p, restoH, sizeL);
            m.push_back(*nueva_celda);
            n++;
        }
    }

    double restoV = fmod(width,sizeL);  
    double areaV = restoV*sizeL;//Area de los ultimos cuadrados en la vertical
    bool v = false;

    if(areaV/areaCuadrados > 0.8){
        numV++;
        v = true;
    }
    
    if(v){  
        for (int j=0;j<numH;j++){ //creo celda
            //punto izq abajo de las celdas
            p.SetX(j*sizeL);
            p.SetY((numV-1)*sizeL);
            Celda *nueva_celda = new CuatroLados(n, p, sizeL, restoV);
            m.push_back(*nueva_celda);
            n++;
        }
    }

    //Ultimo Cuadrado (i=length,j=width)

    double areaU = restoH*restoV;//Area del ultimo cuadrado (i,j)    

    if(areaU/areaCuadrados > 0.8){
        Point2D p ((numH-1)*sizeL, (numV-1)*sizeL); //punto izq abajo de las celdas
        Celda *nueva_celda = new CuatroLados(n, p, restoH, restoV);
        m.push_back(*nueva_celda);
        n++;
    }

    for(int k=0; k<m.size(); k++){

        m[k].SetState(escenario);

    }  
    
    this->ladoCuadrados = sizeL;
    this-> columnas = numH;
    this->filas = numV; 
    this-> cellDecomp = m;
    this->num = n;

}


void Malla::Descanso(){

    vector<int> descanso;

    for(int i=0; i<cellDecomp.size();i++){

            if(cellDecomp[i].GetEsquina(0).GetY()==0 || cellDecomp[i].GetEsquina(0).GetX()==0 || cellDecomp[i].GetEsquina(0).GetY()==(filas-1)*ladoCuadrados || cellDecomp[i].GetEsquina(0).GetX()==(columnas-1)*ladoCuadrados){                 
                descanso.push_back(cellDecomp[i].GetNum());
            }
        }

    this-> zonaDescanso = descanso;

}

