#include "Graph.h"

using namespace boost;

Graph::Graph(){
}
Graph::~Graph(){
}

Graph::Graph(CellDecomp m){  
    
    typedef adjacency_list <vecS,vecS,directedS,property<vertex_distance_t, int>,property<edge_weight_t, int>, no_property, listS> graph_t;
	graph_t g;
    property_map<graph_t, vertex_distance_t>::type distance = get(vertex_distance_t(), g);
    
     
    for(int i=0; i<m.GetSize(); i++){ 
        if(CeldaDescanso(m, m.GetCelda(i)) && m.GetCelda(i).GetState()==0){
            for(int j=0; j<m.GetSize(); j++){                            
                if(CeldaDescanso(m, m.GetCelda(j))  && m.GetCelda(j).GetState()==0 && i!=j && vecino(m.GetCelda(i), m.GetCelda(j))){      
                    add_edge(m.GetCelda(i).GetNum(), m.GetCelda(j).GetNum(),1 , g); //cambiar peso del arco dependiendo de estado de celda
                    
                }

            }

        }
    }  

     this->graph = g;     	
}

adjacency_list <vecS,vecS,directedS,property<vertex_distance_t, int>,property<edge_weight_t, int>, no_property, listS> Graph::GetGraph (){
    return graph;
}

bool Graph::vecino (Celda c1, Celda c2){

    //c1.print();
    //c2.print();
    typedef boost::geometry::model::d2::point_xy<double> point_xy;
    typedef boost::geometry::model::polygon<point_xy> polygon;  
    typedef boost::geometry::model::linestring<point_xy> linestring;

    polygon poly1, poly2;

    for(int i=0; i<c1.GetEsquinas().size(); i++){
        boost::geometry::append(poly1.outer(), point_xy(c1.GetEsquina(i).GetX(),c1.GetEsquina(i).GetY()));    
    }
    boost::geometry::append(poly1.outer(), point_xy(c1.GetEsquina(0).GetX(),c1.GetEsquina(0).GetY())); //volver a añadir la esquina 0 para cerrar el poligono
    for(int j=0; j<c2.GetEsquinas().size(); j++){
        boost::geometry::append(poly2.outer(), point_xy(c2.GetEsquina(j).GetX(),c2.GetEsquina(j).GetY()));    
    }
    boost::geometry::append(poly2.outer(), point_xy(c2.GetEsquina(0).GetX(),c2.GetEsquina(0).GetY())); //volver a añadir la esquina 0 para cerrar el poligono
    
    linestring output;

    boost::geometry::intersection(poly1, poly2, output); 
    double l = bg::length(output);

    return (l>1); //dejamos un punto para las diagonales


}

bool Graph::CeldaDescanso(CellDecomp m, Celda c1){
    bool descanso = true;
    for(int i=0; i<m.GetAreaDescanso().size();i++){
        if(c1.GetNum()==m.GetAreaDescanso()[i]){
            descanso = false;
            i=m.GetAreaDescanso().size();

        }
    }

    return descanso;
}

void Graph::print(){

      for (auto vertex = vertices(graph); vertex.first != vertex.second; 
         ++vertex.first){
        std::cout << *vertex.first << " is connected with ";
        for (auto neighbour = adjacent_vertices(*vertex.first, graph);
             neighbour.first != neighbour.second; ++neighbour.first){
            std::cout << *neighbour.first << " ";
        }
        std::cout<<std::endl;
    }
    
}

void Graph::DibujarGraph(){
    ofstream dotfile("grafo.dot");
    write_graphviz(dotfile , graph);
    system("dot -Tpng grafo.dot -o grafo.png");
}