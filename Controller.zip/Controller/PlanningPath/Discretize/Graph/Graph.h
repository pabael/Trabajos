#ifndef GRAFOCELLL_H
#define GRAFOCELLL_H

#include <iostream>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/graphviz.hpp>
#include <boost/graph/graph_traits.hpp>
#include <boost/graph/dijkstra_shortest_paths.hpp>
#include <boost/property_map/property_map.hpp>
#include <boost/config.hpp>
#include "../CellDecomp/CellDecomp.h"
#include "../CellDecomp/Malla/Malla.h"
//#include"../../../ClasesNecesarias/Segment.h"
using namespace boost;
namespace bg = boost::geometry;
namespace bgm = boost::geometry::model;
using namespace boost::assign;

class Graph 
{
private:

	typedef adjacency_list <vecS,vecS,directedS,property<vertex_distance_t, int>,property<edge_weight_t, int>, no_property, listS> graph_t;
	graph_t graph;



public: 
	Graph();
	~Graph();
	Graph(CellDecomp m);
	bool vecino (Celda c1, Celda c2);
	bool CeldaDescanso(CellDecomp m, Celda c1);
	void print();
	graph_t GetGraph ();
	void DibujarGraph();
};

#endif
