#ifndef PLANIFICADOR_H
#define PLANIFICADOR_H

#include "../PlanningPath.h"
#include "../../../Scene/Scene.h"
#include "../../../ClasesNecesarias/Point2D.h"
#include <iostream>
#include <string>
#include <fstream>

class Planificador
{

private:
    vector<vector<Point2D>> paths; 
    CellDecomp celldecomp;
    PlanningPath planningpath;
    Graph grafo;
    

public:
    Planificador();
    ~Planificador();
    Planificador(string nombre, scene escenario, Mat im);
    vector<vector<Point2D>> GetPaths();
    void dibujarTrayectorias(Mat im, scene escenario);
    void print();

    void PlanCellDecomp(string nombre, scene escenario, mission mision,Mat im);
    void PuntosMedios(CellDecomp m, PlanningPath plan);
    PlanningPath GetPlanningPath();
    CellDecomp GetCellDecomp();
    Graph GetGrafo();


};

#endif