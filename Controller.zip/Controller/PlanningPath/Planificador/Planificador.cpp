#include "Planificador.h"

Planificador::Planificador(){
}
Planificador::~Planificador(){
}

Planificador::Planificador(string nombre, scene escenario, Mat im){

    ifstream datos(nombre);
    Json::Reader reader;
    Json::Value j;
    reader.parse(datos,j);
    string discretize = j["Discretize"].asString();
    mission mision(nombre);
    if(discretize=="CellDescomp"){ 
        PlanCellDecomp(nombre, escenario,mision, im);
    } else if(discretize=="Voronoi"){ }    
        
        

}
void Planificador::PlanCellDecomp(string nombre, scene escenario, mission mision, Mat im){

    ifstream datos(nombre);
    Json::Reader reader;
    Json::Value j;
    reader.parse(datos,j);
    string cellDecomp = j["Celdas"].asString();
    string metodo = j["CeldasToPoints"].asString();

    CellDecomp *descomposicion;
    if(cellDecomp=="Cuadrados"){
           descomposicion = new Malla (escenario);
    } else {
           descomposicion = new Malla (escenario);
    } // en un futuro se daran otras opciones de formas


    descomposicion->Dibujo(im, escenario);
    waitKey(20);

    Graph g(*descomposicion);
    //g.DibujarGraph();

    PlanningPath planning (mision, g, *descomposicion, escenario);   
    planning.CeldaInicialRealSim(*descomposicion) ;

    if(metodo=="PuntosMedios"){
        PuntosMedios(*descomposicion,  planning);
    }

    this -> celldecomp = *descomposicion;
    this -> planningpath = planning;
    this -> grafo = g;



}

CellDecomp Planificador::GetCellDecomp(){
    return celldecomp;
}
PlanningPath Planificador::GetPlanningPath(){
    return planningpath;
}

void Planificador::PuntosMedios(CellDecomp m, PlanningPath plan){
        vector<Point2D> camino;
        Point2D p, p1, p2;
        vector<vector<Point2D>> trayectorias;
        vector<vector<int>> caminos=plan.GetCaminos();
        vector <int> puntosIguales;
        
        if(caminos.size()!=0){
            for(int k=0; k<caminos.size();k++){   
                for(int h=0; h<caminos[k].size(); h++){
                    p.SetX(m.GetCelda(caminos[k][h]).GetCentro().GetX());
                    p.SetY(m.GetCelda(caminos[k][h]).GetCentro().GetY());
                    camino.push_back(p); 
                } 
                   
                    trayectorias.push_back(camino);
                    camino.clear();        
            }          

            if(trayectorias.size()>0){
                
                this -> paths = trayectorias;
                
            }

        }
    }

    void Planificador::dibujarTrayectorias(Mat im, scene escenario){

    Point2d p1, p2, p0;
    int lineType = LINE_4;
    int thickness = 2;
    Scalar color;
    int c=10;
        
        for(int i=0; i<paths.size(); i++){
            p0=escenario.ConversionPlatformToCV(paths[i][0]);
            circle(im, p0, 5, Scalar (255, 0, 0), thickness);
            p0=escenario.ConversionPlatformToCV(paths[i][paths[i].size()-1]);
            circle(im, p0, 5, Scalar (0, 255, 255), thickness);

            color = Scalar (150, c+i*20, 0);
            for(int j=0; j<paths[i].size()-1;j++){
                
                p1 = escenario.ConversionPlatformToCV(paths[i][j]);
                p2 = escenario.ConversionPlatformToCV(paths[i][j+1]);
                line ( im,p1, p2, color, thickness, lineType );

            }

        }
        imshow("Trayectorias", im);
    }

    void Planificador::print(){

        cout << "trayectoria: ";
        for(int i=0; i<paths.size();i++){ 
            for(int j=0; j<paths[i].size();j++){
                paths[i][j].print();
            }
            cout << "\n";
        }
    }


vector<vector<Point2D>> Planificador::GetPaths(){
    return paths;
}

Graph Planificador::GetGrafo(){
    return grafo;
}

