
#ifndef PLANNINGPATH_H
#define PLANNINGPATH_H

#include "../Mission/Mission.h"
#include "Discretize/Graph/Graph.h"
#include "../../Scene/Scene.h"
#include "Discretize/CellDecomp/Malla/Malla.h"

class PlanningPath{

private:

vector<vector<int>> caminos; //trayectorias con las celdas
vector<int> celdaInicialRobots; //donde empiezan los robots
vector<int> CeldasDestinos;

public:

PlanningPath();
~PlanningPath();
PlanningPath(mission mision, Graph graph, CellDecomp m, scene escenario);
vector<vector<int>> GetCaminos();
vector<int> GetRobotQueCelda();
vector<int> GetDestinoQueCelda();
void RobotQueCeldaSimulador(int num, int celda);
void RobotQueCeldaInicialSimulador();
void CeldaInicialRealSim(CellDecomp m);
void RobotQueCelda(CellDecomp m, scene escenario);
void DestinoQueCelda(CellDecomp m, mission mision);
void print();


};

#endif